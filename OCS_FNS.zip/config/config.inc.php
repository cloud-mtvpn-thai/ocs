<?php 
$host ="localhost";
$database="null";
$user_name="null";
$password="null";
$koneksi = mysql_connect($host, $user_name, $password);
$pilihdatabase = mysql_select_db($database, $koneksi);
?>