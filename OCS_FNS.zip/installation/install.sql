SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
SET time_zone = "+07:00";
CREATE TABLE IF NOT EXISTS `server` (
  `id` int(10) NOT NULL AUTO_INCREMENT,
  `servername` varchar(255) NOT NULL,
  `country` varchar(30) NOT NULL,
  `host` varchar(255) NOT NULL,
  `openssh` varchar(255) NOT NULL,
  `dropbear` varchar(255) NOT NULL,
  `limitacc` varchar(255) NOT NULL,
  `info` varchar(255) NOT NULL,
  `badvpn` varchar(20) NOT NULL,  
  `price` int(10) NOT NULL,
  `root_pass` varchar(500) NOT NULL,
  `active` tinyint(1) NOT NULL DEFAULT '1',
  PRIMARY KEY (`id`)
) ENGINE=InnoDB  DEFAULT CHARSET=latin1 AUTO_INCREMENT=7 ;
CREATE TABLE IF NOT EXISTS `user` (
  `id` int(10) NOT NULL AUTO_INCREMENT,
  `email` varchar(255) NOT NULL,
  `firstname` varchar(255) NOT NULL,
  `lastname` varchar(255) NOT NULL,
  `username` varchar(255) NOT NULL,
  `password` varchar(60) NOT NULL,
  `saldo` int(10) NOT NULL DEFAULT '0',
  `type` tinyint(1) NOT NULL DEFAULT '2',
  `active` tinyint(1) NOT NULL DEFAULT '1',
  PRIMARY KEY (`id`),
  UNIQUE KEY `username` (`username`)
) ENGINE=InnoDB  DEFAULT CHARSET=latin1 AUTO_INCREMENT=12 ;
CREATE TABLE IF NOT EXISTS `dataimage` (
  `idimg` int(11) NOT NULL,
  `transfer` char(20) DEFAULT NULL,
  `bank` char(20) DEFAULT NULL,
  `image` varchar(150) DEFAULT NULL,
  `nama` varchar(30) DEFAULT NULL,
  `emailakun` varchar(255) DEFAULT NULL,
  `namauser` varchar(255) DEFAULT NULL,
  `newname` varchar(105) DEFAULT NULL,
  PRIMARY KEY  (`idimg`)
) ENGINE=InnoDB  DEFAULT CHARSET=utf8 AUTO_INCREMENT=27 ;
CREATE TABLE IF NOT EXISTS `pengaturan` (
  `pengaturan_id` int(11) NOT NULL,
  `nama_website` varchar(50) NOT NULL,
  `meta_title` text NOT NULL,
  `meta_description` text NOT NULL,
  `meta_keyword` text NOT NULL,
  `meta_author` text NOT NULL,
  `pengumuman` text,
  `hubungikami` text,
  `copyright` varchar(230) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci NOT NULL,
  PRIMARY KEY (`pengaturan_id`)
) ENGINE=InnoDB  DEFAULT CHARSET=utf8 AUTO_INCREMENT=27 ;

INSERT INTO `pengaturan` (`pengaturan_id`, `nama_website`, `meta_title`, `meta_description`, `meta_keyword`, `meta_author`, `pengumuman`, `hubungikami`, `copyright`) VALUES
(1, 'fornesia', 'Reseller Panel', 'Menyediakan akun SSH & VPN premium dengan server yang bervariasi dan terletak di datacenter dengan kualitas terbaik dan koneksi tercepat.', 'Reseller SSH, openvpn, Fast SSH', 'fornesia', 'Tolong ...\r\nDiisii...\r\nyah...\r\nPengumumanya..', 'WA:\r\nFB:\r\nBCA:\r\nBBM:', 'Copyright Â© 2017');
