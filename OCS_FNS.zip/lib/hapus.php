<?php

include "../config/config.inc.php";
$dataimg = "SELECT idimg from dataimage order by idimg desc limit 1";
$bacadataimg = mysql_query($dataimg);
$select_result = mysql_fetch_array($bacadataimg);
$idimg= $select_result['idimg'];		

    $sql="DELETE FROM dataimage WHERE idimg='$idimg'";
    $result=mysql_query($sql);

header("Location: ../invoice.php");
?> 