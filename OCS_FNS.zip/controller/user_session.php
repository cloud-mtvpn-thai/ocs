<?php
session_start();
if (isset($_SESSION['id']) && $_SESSION['id'] == true) {
    echo "";
} else {
    header("location:/home");
}
$id = $_SESSION['id'];		
$data = "SELECT * from user WHERE id ='$id'";
$bacadata = mysql_query($data);
$row = mysql_fetch_array($bacadata);

$userType = $row['type'];

if($userType == '2'){
   
} else {
    header("location:/home");
}
?>