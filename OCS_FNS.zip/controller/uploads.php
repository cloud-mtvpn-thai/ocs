<?php

//koneksi ke database
include "config/config.inc.php";		

//menangkap posting dari field input form

if(isset($_POST['nama'])){
$nama        = $_POST['nama'];
}
if(isset($_POST['transfer'])){
$transfer    = $_POST['transfer'];
}
if(isset($_POST['bank'])){
$bank        = $_POST['bank'];
}
if(isset($_POST['emailakun'])){
$emailakun        = $_POST['emailakun'];
}
if(isset($_POST['namauser'])){
$namauser        = $_POST['namauser'];
}


if (!empty($_POST['nama']['transfer']['bank']['emailakun']['namauser'])){
$nama        = $_POST['nama'];
$transfer    = $_POST['transfer'];
$bank        = $_POST['bank'];
$emailakun        = $_POST['emailakun'];
$namauser        = $_POST['namauser'];
}
else 
{
        echo "	
		
		";
   }

$namafile= $_FILES['filegbr']['name'];
$namafolder="gambar/"; //folder tempat menyimpan file
if (!empty($_FILES["filegbr"]["tmp_name"]))
{
    $jenis_gambar=$_FILES['filegbr']['type']; //memeriksa format gambar
    if($jenis_gambar=="image/jpeg" || $jenis_gambar=="image/jpg" || $jenis_gambar=="image/gif" || $jenis_gambar=="image/png")
    {           
        $lampiran = $namafolder . basename($namafile); 
        
        //mengupload gambar dan update row table database dengan path folder dan nama image		
        if (move_uploaded_file($_FILES['filegbr']['tmp_name'], $lampiran)) {
            
			$query_insert = "INSERT INTO dataimage (emailakun,namauser,nama,transfer,bank,image)
			VALUES ('$emailakun','$namauser','$nama','$transfer','$bank','$namafile')";
			$insert = mysql_query($query_insert);
			
$dataimg = "SELECT idimg,image from dataimage order by idimg desc limit 1";
$bacadataimg = mysql_query($dataimg);
$select_result = mysql_fetch_array($bacadataimg);
$idimg    = $select_result['idimg'];
$image = $select_result['image'];

if ($insert)
{
$updatename    = "UPDATE dataimage SET newname = CONCAT(idimg, '-',image)";
$rename     = mysql_query($updatename);
$dash = '-';
rename($lampiran,$namafolder.$idimg.$dash.$image);

}

else
{}

$bacanm = "SELECT newname from dataimage order by idimg desc limit 1";
$baca     = mysql_query($bacanm);
$select_result = mysql_fetch_array($baca);
$newname    = $select_result['newname'];

			echo"
			<div class='callout callout-success'>
                <h4>Sukses !</h4>

                <p>Konfirmasi Pembayaran Sukses. Silahkan Tunggu Proses Pengecekan Atau Hubungi Admin</p>
              </div>
			  <div class='box-body table-responsive no-padding'>
              <table class='table table-hover'>
                <tr>
                  
                  <th>Email</th>
                  <th>Username</th>
                  <th>Nama</th>
                  <th>Transfer</th>
				  <th>Bank</th>
				  <th>Lampiran</th>
                </tr>
				                <tr>
                                        
                                        <td>$emailakun</td>
                                        <td>$namauser</td>                                    
                                        <td>$nama</td>
										<td>$transfer</td>
										<td>$bank</td>
										<td><a href='$namafolder$newname'>View</a></td>
				                </tr>
              </table>
            </div>";
			
			
			//Jika gagal upload, tampilkan pesan Gagal		
        } else {
           echo "
		   		<div class='callout callout-danger'>
                <h4>Gagal !</h4>

                <p>Gambar gagal dikirim</p>
              </div>
		   ";
        }
   } else {
        echo "
		   		<div class='callout callout-danger'>
                <h4>Gagal !</h4>

                <p>Jenis gambar yang anda kirim salah. Harus .jpg .gif .png</p>
              </div>		
		
		";
   }
} else {
    echo "
			    <div class='callout callout-danger'>
                <h4>Gagal !</h4>

                <p>Anda belum memilih gambar</p>
              </div>
	";
}
?>