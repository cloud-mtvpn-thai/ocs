<?php
$fnskontakkami = "SELECT * from pengaturan";
$readkontakkami = mysql_query($fnskontakkami);
$sett_result = mysql_fetch_array($readkontakkami);
	$hubungikami = $sett_result['hubungikami'];

if(isset($_POST['savekontakkami']))
{	
	$hubungikami = $_POST['hubungikami'];
	
	mysql_query("UPDATE pengaturan SET hubungikami ='$hubungikami'")
				or die(mysql_error()); 				
	echo "		<div class='alert alert-success alert-dismissible'>
                <button type='button' class='close' data-dismiss='alert' aria-hidden='true'>&times;</button>
                <h4><i class='fa fa-thumbs-o-up'></i> Sukses</h4>
                Kontak berhasil disimpan!
              </div>
	
	
	";
				
}
?>